# include "std_lib_facilities.h"


int maxOfTwo(int a , int b) {
    if( a >  b) {
        cout << "A Is greater than B" << endl;
    } else {
        cout << "B Is greater than or equal to A" << endl;
    }
    return 0;
}


int fibonacci(int n) {
    int a = 0;
    int b = 1;
    cout << " Fibonacci Numbers: " << endl;
    for (int x = 1; x < n +1; ++x) {
        cout << x << " " << b << endl;
        int temp = b;
        b += a;
        a = temp;
    }
    cout << "----" << endl;
    return b;
}

int squareNumberSum(int n) {
    int totalSum = 0;
    for(int i = 1; i<n+1; ++i) {
        totalSum += pow(i,2);
        cout << pow(i,2) << endl;
    }
    cout << "----" << endl;
    cout << totalSum << endl;
    return totalSum;
}


int triangleNumersBelow(int n) {
    int acc = 1;
    int num = 2;
    cout << "Triangle numbers below " << n << ":" << endl;
    while(acc < n) {
        cout << acc << endl;
        acc += num;
        num += 1;
    }
    return 0;
}


bool isPrime(int n) {
    for(int j = 2; j < n+1; ++j) {
        if ((n%j) == 0) {
            return false;
        }
    return true;
    }
}


int naivePrimeNumberSearch(int n) {
    for (int num = 2; num < n; ++num) {
        if (isPrime(num)) {
            cout << num << " is a prime" << endl;
        }
    }
    return 0;
}

int findGreatestDivisor(int n) {
    for(int div = (n-1); div > 0; --div) {
        if((n%div)== 0) {
            return div;
        }
    }
}

int main(){
    
    cout << "Oppgave 2 a og b)" << endl;
    cout << maxOfTwo(5,6) << endl;
    
    cout << "Oppgave 2c)" << endl;
    cout << fibonacci(5) << endl;

    cout << "Oppgave 2d)" << endl;
    cout << squareNumberSum(8) << endl;
    
    cout << "Oppgave 2e)" << endl;
    cout << triangleNumersBelow(14) << endl;

    cout << "Oppgave 2 f og g)" << endl;
    cout << naivePrimeNumberSearch(14) << endl;
    
    cout << "Oppgave 2h)" << endl;
    cout << findGreatestDivisor(14) << endl;

    return 0;
}