int main() {
    cout << naivePrimeNumberSearch(14) << endl;
}