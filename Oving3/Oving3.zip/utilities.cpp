#include <std_lib_facilities.h>
#include <utuilities.hpp>
#include <cannonball.hpp>

int randomWithLimits(int lowerLimit , int  upperLimit) {
    random_device rd;
    default_random_engine generator(rd());
    uniform_real_distribution<double> distribution(lowerLimit , upperLimit);

    double number = distribution(generator);
    int intNumber = static_cast<int> (number);
    return intNumber;
}

void playTargetPractice(){
    int distanceToTarget = randomWithLimits(100 , 1000); //min og max lengde.
    for (int counter=0; counter<10; counter++) {
        double deg = getUserInputTheta();
        double absVelocity = getUserInputAbsVelocity();

        double velocityX = getVelocityX(absVelocity , deg);
        double velocityY = getVelocityY(absVelocity , deg);

        if(hit(distanceToTarget, velocityX , velocityY)){
            cout << "Flight time is: ";
            printTime(flightTime(velocityY));
            cout << "\nDistance traveled is: " << getDistanceTraveled(velocityX , velocityY) << endl;
            cout << "Distace to target is: " << targetPractice(distanceToTarget , velocityX , velocityY) <<" meters" << endl;
            cout << "Hit congratulations!!" << endl;
            return;
        }else{
            cout << "Flight time is: ";
            printTime(flightTime(velocityY));
            cout << "\nDistance traveled is: " << getDistanceTraveled(velocityX , velocityY) << endl;
            cout << "Target at: " << distanceToTarget << endl;
            cout << "Distace to target is: " << targetPractice(distanceToTarget , velocityX , velocityY) <<" meters" << endl;
            cout<< "Miss, try again." << endl;
        }




    }
    cout << "Du var ikke mye treffsikker...." << endl;
    return;
}