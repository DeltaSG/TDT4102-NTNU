#pragma once 

int randomWithLimits(int lowerLimit , int upperLimit);

void playTargetPractice();