#pragma once

void playMastermind();
int checkCharactersAndPosition(int size , string code ,string guess);
int checkCharacters(string code , string guess);