#pragma once

void testCallByValue();
void testCallByRefrence();

//oppgave 3)
void testString();