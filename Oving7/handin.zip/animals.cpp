#include <std_lib_facilities.h>

#include "animals.h"

Animals::Animals(string name , int age): name{name} , age{age}{};

void testAnimal(){
    Dog a("Heisan" , 5);
    Dog b("Biscuit" , 10);
    Cat c("Tibbels" , 4);
    Cat d("Tom" , 20);

    //vector<unique_ptr<Animals>> anim{};
    //anim.push_back(a);
    a.toString();
    b.toString();
    c.toString();
    d.toString();
}